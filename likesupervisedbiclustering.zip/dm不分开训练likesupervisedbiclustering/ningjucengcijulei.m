function clusterrowindex=ningjucengcijulei(X,Thc)

   %X=[1 22  11  3.5 13 2 21  3  23 12  4  8 0.00002];
    len=size(X,1);
   % X=yiliezuidazuixiao(X);  
    Y2=pdist(X); 
    Z2=linkage(Y2);
    
      % Thc=0.1;
    A=Z2(:,3)-Thc;
    B=A(A<0);
    len2=size(B,1);
    
    Zsmall=zeros(len2,3);
    Zsmall(:,1)=(1:len2)'+len;
    Zsmall(:,2:3)=Z2(1:len2,1:2);
    
    wholerowindex=1:size(Zsmall,1);
    allusedrow=[];
    k=0; 
    clusterrowindex=[];
    while(size(Zsmall,1)>0)
           n=size(Zsmall,1);
           whole=Zsmall(n,2:3);
           usedrow=n;
           [value,row]=extractclusters(whole(1),whole(2),Zsmall,len);
           deleterow=[n row];
           Zsmall(deleterow,:)=[];  
           usedrow=rowindextransform([n row],wholerowindex,allusedrow);
           allusedrow=[allusedrow usedrow];
           if length(usedrow)>3
               k=k+1;
               clusterrowindex(k).rownumber=usedrow;
               clusterrowindex(k).order=k;
           end
   
    end
     
    

