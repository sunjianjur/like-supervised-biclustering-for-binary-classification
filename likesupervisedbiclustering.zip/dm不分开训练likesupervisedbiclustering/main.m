clear;clc;
result=[];
alpha=1.5;
delta=0.1;
Thc=0.005; confidence=0.65;

data=load('dataset_1062.txt');
n=size(data,1);
pn=round(0.1*n);
index=zeros(10,pn);
whole=1:n;

for i=1:10
    index100=randperm(length(whole),pn);
    index(i,:)=whole(index100);
    whole=setdiff(whole,index(i,:));
end
for k=1:10
        testindex=index(k,:);
        tdata=data(testindex,:);
        traindata=data(setdiff(1:n,testindex),:);
        testlabel=tdata(:,1);
        testdata=tdata(:,2:end);
        b=-1; m=1; 

        fdata=traindata(:,2:end);
        gyhdata=traindata;
        gyhdata(:,2:end)=suoyouliezuidazuixiao(gyhdata(:,2:end));
        [brules,mrules,zeroindex]=searchrulesfromwholedata(fdata,gyhdata,delta,alpha,Thc,confidence);
        %delete overlap biclusters
        brules=deleteoverlap(brules);
        mrules=deleteoverlap(mrules);       
        [strongclassifier,W]=adaboost(brules,mrules,traindata);
             
        %improve the rules
        [brules2,mrules2]=secondsearchimprovebicluster(traindata,brules,mrules,strongclassifier,delta);
        
        %in above step, brules and mrules are better changed
        %in following step, zeroindex should be trained once again by increasing delta.
        %combine the new rules found from zerorules to brule2 and mrules2
        [brules2,mrules2]=retraindeletedbiclusters(zeroindex,brules2,mrules2,delta,traindata,confidence);
        
        brules2=deleteoverlap(brules2);
        mrules2=deleteoverlap(mrules2);

        [strongclassifier2,W2]=adaboost(brules2,mrules2,traindata);
        testresult2=[];
        for i=1:size(testdata,1)
           testresult2=[testresult2;  predictlabel(strongclassifier2,testdata(i,:))];        
        end
        testresult2=sign(testresult2);
        diff2=testlabel-testresult2;
        error=length(find(diff2~=0))/length(diff2);
        tgroups=testlabel;
        classes1=testresult2;
        tn=0; 
        tp=0;
        fn=0;
        fp=0;
        for i=1:length(tgroups)
            if(tgroups(i)==-1)&&(classes1(i)==-1)
            tn=tn+1;
            elseif (tgroups(i)==1)&&(classes1(i)==1)
            tp=tp+1;
            elseif (tgroups(i)==1)&&(classes1(i)==-1)
            fn=fn+1;
            else
            fp=fp+1;
            end
        end
        sensitivity=tp/(tp+fn);
        specifity=tn/(tn+fp);
        result=[result; [1-error specifity sensitivity]]

end
