function [ecs]=ENT(data)
[r,c]=size(data);
e=0;
for j=1:c
    di=data(:,j);
    dlgs=unique(di);   
    pos=zeros(length(dlgs));
    for i=1:length(dlgs)
        pos(i)=length(find(di==dlgs(i)));
    end    
    pos=pos/r;
    for i=1:length(dlgs)
        e=e-pos(i)*log(pos(i));
    end    
end
e=e/c;

fc=0;
for j=1:c
    fc=fc+std(data(:,j));
end
fc=fc/c;
ecs=e*fc;

end