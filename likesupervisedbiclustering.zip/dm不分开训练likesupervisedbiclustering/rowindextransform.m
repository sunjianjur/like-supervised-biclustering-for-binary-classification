function row=rowindextransform(row,wholerowindex,allusedrow)

remainindex=setdiff(wholerowindex,allusedrow);
row=remainindex(row);

end