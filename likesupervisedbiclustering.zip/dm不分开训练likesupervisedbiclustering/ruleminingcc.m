function [rule]=ruleminingcc(data,r,c,wholer,wholec,delta,alpha)
entropy=ENT(data(r,c));

%delete multiple row/column
deltacombine=[10000 entropy];
while((entropy>delta)&&deltacombine(end-1)>deltacombine(end))
    ER=[];
    for i=1:length(r)
        tempr=setdiff(r,r(i));
         ER=[ER ENT(data(tempr,c))];
    end    
    ER=entropy-ER;
    bigrpos=find(ER>entropy*alpha);
    r=setdiff(r,r(bigrpos));
    entropy=ENT(data(r,c));

    EC=[];
    for i=1:length(c)
       EC=[EC ENT(data(r,setdiff(c,c(i))))];
    end
    EC=entropy-EC;
    bigcpos=find(EC>entropy*alpha);
    c=setdiff(c,c(bigcpos));
    entropy=ENT(data(r,c));
    
    deltacombine=[deltacombine entropy];
end

%delete single row/column
deltacombine=[10000 entropy];
while((entropy>delta)&&deltacombine(end-1)>deltacombine(end))
     ER=[];
    for i=1:length(r)
        tempr=setdiff(r,r(i));
         ER=[ER ENT(data(tempr,c))];
    end    
    [minre,minrpos]=min(ER);

    EC=[];
    for i=1:length(c)
       EC=[EC ENT(data(r,setdiff(c,c(i))))];
    end
    [mince,mincpos]=min(EC);

    if minre<mince
        r=setdiff(r,r(minrpos));
    else
        c=setdiff(c,c(mincpos));
    end

    entropy=ENT(data(r,c));
end

%add row/column
% remainr=setdiff(wholer,r)';
% remainc=setdiff(wholec,c)';
% tiji=[0; sum(r)+sum(c)];
% while(entropy<delta)&&(tiji(end,:)>tiji(end-1,:))
%     ER=[];
%     for i=1:length(remainr)
%        tempr=[r' remainr(i)];
%        ER=[ER ENT(data(tempr,c))];
%     end
%     r=[r remainr(find(ER<=entropy))];
%     remainr=setdiff(wholer,r);
%     entropy=ENT(data(r,c));
%     
%      EC=[];
%     for i=1:length(remainc)
%        tempc=[c remainc(i)];
%        EC=[EC ENT(data(r,tempc))];
%     end
%     c=[c remainc(find(EC<=entropy))];
%     remainc=setdiff(wholec,c);
%     entropy=ENT(data(r,c));
%     tiji=[tiji; sum(r)+sum(c)];
% end

r=r';

   if (ENT(data(r,c))<=delta)&&(length(r)>4)&&(length(c)>3)    
       rule=[length(r) length(c) c  mean(data(r,c)) r ENT(data(r,c))];
   else
       rule=[];
   end
   
end