function [brules,mrules]=retraindeletedbiclusters(zeroindex,brules,mrules,delta,traindata,confidence)
wholelabel=traindata(:,1);    
data=traindata(:,2:end);  
%retrain delta no changes, when length of columns is the same as the threshold, 
%not delete the rows any more, only delete the rows.
nb=size(brules,2);
nm=size(mrules,2);
for j=1:size(zeroindex,2)
         seedindex=zeroindex(j).real;
         label=wholelabel(seedindex);
         rule=findrule2(data(seedindex,:),delta,label,confidence);
         if ~isempty(rule)   
             if rule(end)==-1                 
                  nb=nb+1;
                  brules(nb).real=rule(1:end-1);
                  brules(nb).image=nb;
             elseif rule(end)==1                 
                 nm=nm+1;
                 mrules(nm).real=rule(1:end-1);
                 mrules(nm).image=nm;
             end
         end
end
           
end