function [brule,mrule,zeroindex]=searchrulesfromwholedata(fdata,gyhdata,delta,alpha,Thc,confidence)
brule=[];
mrule=[];
wholelabel=gyhdata(:,1);
data=gyhdata(:,2:end);

[r,c]=size(data);
wholer=1:r;
wholec=1:c;

nb=0;nm=0;nzero=0;
for i=1:c
      datai=data(:,i);
      clusterrowindex=ningjucengcijulei(datai,Thc);

     for j=1:size(clusterrowindex,2)
         seedindex=clusterrowindex(j).rownumber;
         label=wholelabel(seedindex);
         rule=findrule(fdata(seedindex,:),delta,label,confidence);
             if rule(end)==-1
                 nb=nb+1;
                 brule(nb).real=rule(1:end-1);
                 brule(nb).image=nb;
             elseif rule(end)==1
                 nm=nm+1;
                 mrule(nm).real=rule(1:end-1);
                 mrule(nm).image=nm;
             elseif rule(end)==0
                 nzero=nzero+1;
                  zeroindex(nzero).real=seedindex;
                 zeroindex(nzero).image=nzero;
             end 
     end
 
end

end