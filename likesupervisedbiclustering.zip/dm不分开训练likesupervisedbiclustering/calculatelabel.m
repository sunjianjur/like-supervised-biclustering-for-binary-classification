function [biaoqian,rb,rm]=calculatelabel(lable,confidence)

    nb=length(find(lable==-1));
    nm=length(find(lable==1));
    
    rb=nb/length(lable);
    rm=nm/length(lable);

%     if rb>=confidence
    if rb>0.5
        biaoqian=-1;
    elseif rm>=confidence
        biaoqian=1;
    else
        biaoqian=0;
    end
    
end