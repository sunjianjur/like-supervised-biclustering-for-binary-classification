function [out]=sfbaohan(Finalclassifier,pos)

   all=[];
    for i=1:size(Finalclassifier,2)
       all=[all Finalclassifier(i).c];
    end
    
    if ismember(pos,all)
        out=true;
    else
        out=false;
    end
    
end