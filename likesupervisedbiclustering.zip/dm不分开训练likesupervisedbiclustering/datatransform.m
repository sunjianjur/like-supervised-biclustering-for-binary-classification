function [traindata,tdata]=datatransform(breastcancerwisconsin)

data=breastcancerwisconsin ;
data(:,7)=[];
data(:,1)= data(:,end);
data(:,end)=[];

label=data(:,1);
b=find(label==2);
m=find(label==4);

nb=length(b);
nm=length(m);

bindex1=randperm(nb,round(nb*0.7));
bindex2=b(bindex1);
mindex1=randperm(nm,round(nm*0.7));
mindex2=m(mindex1);

label(b)=-1;
label(m)=1;
data(:,1)=label;

n=length(label);

trainindex=[bindex2; mindex2];
testindex=setdiff(1:n,trainindex);

traindata=data(trainindex,:);
tdata=data(testindex,:);
end
